const express = require("express");
const path = require("path");
let courses = require("./models/course.model");
var cors = require("cors");

const app = express();
const port = 3000;

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
// app.use(cors());
app.get("/courses", cors(), (req, res) => {
  // DB
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  let courseToBeAdded = req.body;
  console.log("Adding new course");
  courses = [...courses, courseToBeAdded]; // push() as well
  res.json({ msg: "success" });
});

app.delete("/courses/:id", (req, res) => {
  let courseId = +req.params.id;

  console.log("Deleting a course (server) for : ", courseId);
  // coming from DB !
  courses = courses.filter((course) => course.id != courseId); // functional prog
  // delete biz logic
  res.json({ msg: "success" });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
