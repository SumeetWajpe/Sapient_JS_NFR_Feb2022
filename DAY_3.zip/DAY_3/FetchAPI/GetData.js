function GetData() {
  return fetch("https://jsonplaceholder.typicode.com/posts");
}
