// function GetData() {
//   return new Promise(function (resolve, reject) {
//     var xmlHttpReq = new XMLHttpRequest();
//     xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/postss");
//     xmlHttpReq.onreadystatechange = function () {
//       if (xmlHttpReq.readyState == 4 && xmlHttpReq.status == 200) {
//         resolve(xmlHttpReq.responseText);
//       } else if (xmlHttpReq.readyState == 4 && xmlHttpReq.status != 200) {
//         reject("Something went wrong !", xmlHttpReq.status);
//       }
//     };
//     xmlHttpReq.send();
//   });
// }

function GetData() {
  if (window.fetch) {
    return fetch("https://jsonplaceholder.typicode.com/posts");
  }
}
