// import Addition, { Product } from "./MathModule.js"; // default export
// import { Add as Addition, Product } from "./MathModule.js";

// console.log("The addition is : " + Addition(20, 30));
// console.log("The product is : " + Product(20, 30));

// OR
import * as MathModule from "./MathModule.js";
console.log("The addition is : " + MathModule.Add(20, 30));
console.log("The product is : " + MathModule.Product(20, 30));
