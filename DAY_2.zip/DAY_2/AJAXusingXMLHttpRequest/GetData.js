function GetData(callback) {
  //1. Instanciate XMLHttpRequest object
  //2. Configure using open(verb,url)
  //3. Register onreadystatechange
  //4. send() -> places the async call
  //5. Get and use the response (when readystate is 4)

  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlHttpReq.onreadystatechange = function () {
    if (xmlHttpReq.readyState == 4 && xmlHttpReq.status == 200) {
      callback(null, xmlHttpReq.responseText);
    } else if (xmlHttpReq.readyState == 4 && xmlHttpReq.status != 200) {
      callback(`Something went wrong ! ${xmlHttpReq.status} !`, null);
    }
  };
  xmlHttpReq.send();
}
